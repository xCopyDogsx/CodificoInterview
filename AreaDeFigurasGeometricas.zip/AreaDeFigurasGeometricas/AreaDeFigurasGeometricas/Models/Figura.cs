﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaDeFigurasGeometricas.Models
{
    public abstract class Figura
    {
        public double Area;
        public abstract double Calcular_Area();
    }
}
