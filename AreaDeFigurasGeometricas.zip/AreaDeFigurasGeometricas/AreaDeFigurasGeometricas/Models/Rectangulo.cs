﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaDeFigurasGeometricas.Models
{
    public class Rectangulo : Figura
    {
        public double Base, Altura;
        public Rectangulo(double b,double a)
        {
            Base = b;
            Altura = a;
        }
        public override double Calcular_Area()
        {
            Area = Base * Altura;
            return Area;
        }
    }
}
