﻿using AreaDeFigurasGeometricas.Models;
using System;

class ProyectoAreasFiguras
{
    static void Main(string[] args)
    {
        while (true)
        {
            string Opcion;
            Console.WriteLine("Escoja que figura desea calcular el area circulo o rectangulo");
            Opcion = Console.ReadLine() ?? "N/A";
            if (Opcion.ToUpper().Equals("CIRCULO"))
            {
                double Radio;
                Console.WriteLine("Ingrese el radio: ");
                Radio = Double.Parse(Console.ReadLine()??"-1");
                var circulo = new Circulo(Radio);
                double Area = circulo.Calcular_Area()<=0?0:circulo.Calcular_Area();
                if(Area>=0) {
                    Console.WriteLine($"El área del circulo es: {Area}");
                }
                if(Area<0)
                {
                    Console.WriteLine("El radio no puede ser negativo o nulo");
                }             
            }

            if (Opcion.ToUpper().Equals("RECTANGULO"))
            {
                double Base,Altura;
                Console.WriteLine("Ingrese la base: ");
                Base = Double.Parse(Console.ReadLine() ?? "-1");
                Console.WriteLine("Ingrese la altura: ");
                Altura = Double.Parse(Console.ReadLine() ?? "-1");
                var rectangulo = new Rectangulo(Base,Altura);
                double Area = rectangulo.Calcular_Area() <= 0 ? 0 : rectangulo.Calcular_Area();
                if (Area >= 0)
                {
                    Console.WriteLine($"El área del rectangulo es: {Area}");
                }
                if (Area < 0)
                {
                    Console.WriteLine("La base y altura no pueden ser negativos o nulos");
                }
            }
            Console.WriteLine("¿Desea continua?");
            string Continuar = Console.ReadLine() ?? "N/A";
            if (Continuar.ToUpper().Equals("NO"))
            {
                break;
            }
        }
        

    
    }
}
