using AreaDeFigurasGeometricas.Models;

namespace PruebaUnitariaAreaFiguras
{
    [TestClass]
    public class PruebaUnitariaAreas
    {
        [TestMethod]
        public void ProbarAreaFiguras()
        {
            Random random = new Random();
            double Radio = random.NextDouble();
            double Base = random.NextDouble();
            double Altura = random.NextDouble();
            var circulo = new Circulo(Radio);
            var rectangulo = new Rectangulo(Base, Altura);
            Assert.IsTrue(circulo.Calcular_Area()==(Math.PI*Math.Pow(Radio,2)));
            Assert.IsTrue(rectangulo.Calcular_Area()==(Base*Altura));
        }
    }
}